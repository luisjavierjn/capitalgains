package com.nubank.capitalgains.exceptions;

public class InputStreamException extends RuntimeException {

    public InputStreamException(String errorMessage, Throwable cause) {
        super(errorMessage, cause);
    }
}
